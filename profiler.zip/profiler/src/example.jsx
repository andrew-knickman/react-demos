const classTitle = <h3>Welcome!</h3>;

{classTitle};